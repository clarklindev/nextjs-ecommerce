-- AlterTable
ALTER TABLE "Product" ALTER COLUMN "isFeatured" SET DEFAULT false;
